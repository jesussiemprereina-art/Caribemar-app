import { useState, useRef, useEffect } from "react";

const ADMIN_PASS = "12345678";
// Plazos en QUINCENAS (10q=5m, 12q=6m, 14q=7m, 15q=7.5m, 18q=9m, 20q=10m, 24q=12m, 36q=18m)
const PLAZOS = [10, 12, 14, 16, 18, 20, 24, 36];
const INICIALES = [15000, 18000, 20000, 22000, 25000, 30000];

// La tasa mensual se convierte a quincenal: tasa_quincenal = tasa_mensual / 2
// Total interés = saldo * tasa_quincenal * num_quincenas
function calcularCuota(precioRD, inicial, quincenas, tasaMensual) {
  const saldo = precioRD - inicial;
  if (saldo <= 0) return null;
  const tasaQ = (tasaMensual / 100) / 2;
  const interes = saldo * tasaQ * quincenas;
  const total = saldo + interes;
  const cuota = total / quincenas;
  return { saldo, total, cuota };
}

const fmt = (n) =>
  n?.toLocaleString("es-DO", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// ─── CATÁLOGO por defecto ───
const CATALOGO_DEFAULT = [
  { id: 1, marca: "Tauro", modelo: "150", precio: 90000 },
  { id: 2, marca: "Nipponia", modelo: "200", precio: 110000 },
  { id: 3, marca: "Loncin", modelo: "125", precio: 75000 },
  { id: 4, marca: "X1000", modelo: "250", precio: 145000 },
  { id: 5, marca: "Super Tucán", modelo: "150", precio: 95000 },
];

// ─── PANEL ADMIN ───
function PanelAdmin({ catalogo, setCatalogo, tasaMensual, setTasaMensual, onClose }) {
  const [newMarca, setNewMarca] = useState("");
  const [newModelo, setNewModelo] = useState("");
  const [newPrecio, setNewPrecio] = useState("");
  const [tasaTemp, setTasaTemp] = useState(tasaMensual);
  const [saved, setSaved] = useState(false);

  const agregarMoto = () => {
    if (!newMarca || !newModelo || !newPrecio) return;
    const nueva = {
      id: Date.now(),
      marca: newMarca.trim(),
      modelo: newModelo.trim(),
      precio: parseFloat(newPrecio),
    };
    setCatalogo((prev) => [...prev, nueva]);
    setNewMarca(""); setNewModelo(""); setNewPrecio("");
  };

  const eliminarMoto = (id) => setCatalogo((prev) => prev.filter((m) => m.id !== id));

  const guardarTasa = () => {
    setTasaMensual(parseFloat(tasaTemp));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="admin-overlay">
      <div className="admin-panel">
        <div className="admin-header">
          <h2>⚙️ Panel Administrador</h2>
          <button className="close-btn" onClick={onClose}>✕</button>
        </div>

        {/* Tasa de interés */}
        <div className="admin-section">
          <h3>Tasa de Interés Mensual</h3>
          <div className="tasa-row">
            <input
              type="number"
              step="0.1"
              min="0"
              max="20"
              value={tasaTemp}
              onChange={(e) => setTasaTemp(e.target.value)}
              className="input-field"
            />
            <span className="tasa-pct">% mensual</span>
            <button className="btn-guardar" onClick={guardarTasa}>
              {saved ? "✓ Guardado" : "Guardar"}
            </button>
          </div>
          <p className="admin-note">
            Aplica (quincenas): {PLAZOS.map(p => `${p}q → ${((p * parseFloat(tasaTemp || 0)) / 2).toFixed(1)}%`).join(" · ")}
          </p>
        </div>

        {/* Catálogo */}
        <div className="admin-section">
          <h3>Catálogo de Motos</h3>
          <div className="catalogo-list">
            {catalogo.map((m) => (
              <div key={m.id} className="catalogo-item">
                <div className="cat-info">
                  <strong>{m.marca} {m.modelo}</strong>
                  <span>RD$ {fmt(m.precio)}</span>
                </div>
                <button className="btn-del" onClick={() => eliminarMoto(m.id)}>🗑</button>
              </div>
            ))}
          </div>

          <div className="add-moto">
            <h4>Agregar moto</h4>
            <div className="add-row">
              <input
                className="input-field"
                placeholder="Marca"
                value={newMarca}
                onChange={(e) => setNewMarca(e.target.value)}
              />
              <input
                className="input-field"
                placeholder="Modelo"
                value={newModelo}
                onChange={(e) => setNewModelo(e.target.value)}
              />
            </div>
            <div className="add-row">
              <input
                className="input-field"
                placeholder="Precio en RD$"
                type="number"
                value={newPrecio}
                onChange={(e) => setNewPrecio(e.target.value)}
              />
              <button className="btn-agregar" onClick={agregarMoto}>+ Agregar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── LOGIN ADMIN ───
function LoginAdmin({ onLogin, onClose }) {
  const [pass, setPass] = useState("");
  const [error, setError] = useState(false);

  const intentar = () => {
    if (pass === ADMIN_PASS) { onLogin(); }
    else { setError(true); setTimeout(() => setError(false), 1500); }
  };

  return (
    <div className="admin-overlay">
      <div className="login-box">
        <button className="close-btn" onClick={onClose}>✕</button>
        <div className="lock-icon">🔐</div>
        <h3>Acceso Administrador</h3>
        <input
          type="password"
          className={`input-field ${error ? "error" : ""}`}
          placeholder="Contraseña"
          value={pass}
          onChange={(e) => setPass(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && intentar()}
          autoFocus
        />
        {error && <p className="error-msg">Contraseña incorrecta</p>}
        <button className="btn-guardar full" onClick={intentar}>Entrar</button>
      </div>
    </div>
  );
}

// ─── CALCULADORA CLIENTE ───
function Calculadora({ catalogo, tasaMensual }) {
  const [motoId, setMotoId] = useState(catalogo[0]?.id ?? null);
  const [inicial, setInicial] = useState(15000);
  const [inicialCustom, setInicialCustom] = useState("");
  const [plazo, setPlazo] = useState(12);

  const moto = catalogo.find((m) => m.id === motoId);
  const inicialFinal = inicialCustom !== "" ? parseFloat(inicialCustom) : inicial;
  const result = moto && inicialFinal >= 15000
    ? calcularCuota(moto.precio, inicialFinal, plazo, tasaMensual)
    : null;

  return (
    <div className="calc-wrapper">
      <div className="calc-header">
        <span className="calc-icon">🏍️</span>
        <h2>Calcula tu Cuota</h2>
        <p>Elige tu moto, inicial y quincenas</p>
      </div>

      <div className="calc-grid">
        {/* Selección de moto */}
        <div className="field-group">
          <label>Selecciona tu moto</label>
          <div className="moto-cards">
            {catalogo.map((m) => (
              <div
                key={m.id}
                className={`moto-card ${motoId === m.id ? "active" : ""}`}
                onClick={() => setMotoId(m.id)}
              >
                <span className="moto-emoji">🏍️</span>
                <div className="moto-nombre">{m.marca} {m.modelo}</div>
                <div className="moto-precio">RD$ {fmt(m.precio)}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Inicial */}
        <div className="field-group">
          <label>Inicial (mínimo RD$15,000)</label>
          <div className="price-pills">
            {INICIALES.map((i) => (
              <button
                key={i}
                className={`pill ${inicialCustom === "" && inicial === i ? "active" : ""}`}
                onClick={() => { setInicial(i); setInicialCustom(""); }}
              >
                {(i / 1000).toFixed(0)}K
              </button>
            ))}
          </div>
          <input
            type="number"
            placeholder="O escribe tu inicial aquí..."
            value={inicialCustom}
            onChange={(e) => setInicialCustom(e.target.value)}
            className="input-field"
            min={15000}
          />
        </div>

        {/* Plazo */}
        <div className="field-group">
          <label>Número de quincenas</label>
          <div className="plazo-pills">
            {PLAZOS.map((p) => (
              <button
                key={p}
                className={`plazo-pill ${plazo === p ? "active" : ""}`}
                onClick={() => setPlazo(p)}
              >
                <span className="plazo-num">{p}</span>
                <span className="plazo-label">quincenas</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {inicialFinal < 15000 && inicialCustom !== "" && (
        <div className="alerta">⚠️ El inicial mínimo es RD$15,000</div>
      )}

      {result ? (
        <div className="cuota-grande">
          <span>Tu cuota quincenal estimada</span>
          <div className="cuota-valor">RD$ {fmt(result.cuota)}</div>
          <span className="cuota-sub">por {plazo} quincenas · inicial RD$ {fmt(inicialFinal)}</span>
        </div>
      ) : (
        <div className="resultado vacio">
          <p>Selecciona una moto, inicial y número de quincenas</p>
        </div>
      )}
    </div>
  );
}

// ─── CHATBOT ───
function buildSystemPrompt(catalogo, tasaMensual) {
  const listaMotos = catalogo.map(m => `- ${m.marca} ${m.modelo}: RD$${fmt(m.precio)}`).join("\n");
  return `Eres el asistente virtual de Inversiones Caribemar SRL, empresa dominicana de venta de motos con financiamiento propio en La Romana, R.D.

CONTACTO: Tel 809-349-4268 · Pedro A. Lluberes #46, La Romana

CATÁLOGO ACTUAL:
${listaMotos}

FINANCIAMIENTO (PAGOS QUINCENALES):
- Inicial mínimo: RD$15,000. Opciones: 15,000 / 18,000 / 20,000 / 22,000 / 25,000 o más.
- Plazos disponibles en QUINCENAS: 10, 12, 14, 16, 18, 20, 24 o 36 quincenas
- Los pagos son QUINCENALES (cada 15 días), no mensuales.
- NUNCA menciones la tasa de interés, porcentajes ni el desglose del cálculo al cliente.
- Solo di la cuota quincenal resultante.

CÓMO COTIZAR (sin revelar la fórmula):
tasaQ = ${tasaMensual / 100} / 2
saldo = precio_moto - inicial
total = saldo + (saldo * tasaQ * quincenas)
cuota = total / quincenas
Muestra solo la cuota quincenal final.

REGLAS:
- Responde en español dominicano, amable y breve.
- Cuando cotices, muestra: modelo, precio, inicial elegido, número de quincenas y cuota QUINCENAL. NADA MÁS.
- Si preguntan por intereses o tasas, di: "El financiamiento incluye todos los costos en la cuota quincenal."
- Si no tienes la info, invita a llamar al 809-349-4268.`;
}

function Chatbot({ catalogo, tasaMensual }) {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "¡Buenas! Soy el asistente de **Caribemar** 🏍️ Puedo cotizarte una moto o resolver tus preguntas. ¿En qué te ayudo?" }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;
    const newMessages = [...messages, { role: "user", content: text }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);
    try {
      // Only send user messages (no leading assistant message)
      const apiMessages = newMessages
        .map((m) => ({ role: m.role, content: m.content }))
        .filter((_, i, arr) => i >= arr.findIndex(x => x.role === "user"));

      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": process.env.REACT_APP_ANTHROPIC_KEY,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true"
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-5-20251001",
          max_tokens: 1000,
          system: buildSystemPrompt(catalogo, tasaMensual),
          messages: apiMessages,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error?.message || `HTTP ${res.status}`);
      }

      const data = await res.json();
      const reply = data.content?.map((b) => b.text || "").join("") || "Sin respuesta.";
      setMessages((prev) => [...prev, { role: "assistant", content: reply }]);
    } catch (err) {
      setMessages((prev) => [...prev, { role: "assistant", content: `⚠️ ${err.message}` }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
  };

  const renderText = (text) =>
    text.split(/(\*\*[^*]+\*\*)/).map((part, i) =>
      part.startsWith("**") ? <strong key={i}>{part.slice(2, -2)}</strong> : part
    );

  const SUGERENCIAS = [
    "¿Qué motos tienen disponibles?",
    "Cotizar Tauro 150 a 24 quincenas",
    "¿Cuál es el inicial mínimo?",
    "¿Dónde están ubicados?",
  ];

  return (
    <div className="chat-wrapper">
      <div className="chat-header">
        <div className="chat-avatar">C</div>
        <div>
          <h2>Asistente Caribemar</h2>
          <span className="online-dot">● En línea</span>
        </div>
      </div>
      <div className="chat-messages">
        {messages.map((m, i) => (
          <div key={i} className={`msg ${m.role}`}>
            {m.role === "assistant" && <div className="msg-avatar">C</div>}
            <div className="msg-bubble">{renderText(m.content)}</div>
          </div>
        ))}
        {loading && (
          <div className="msg assistant">
            <div className="msg-avatar">C</div>
            <div className="msg-bubble typing"><span /><span /><span /></div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>
      {messages.length === 1 && (
        <div className="sugerencias">
          {SUGERENCIAS.map((s) => (
            <button key={s} className="sug-pill" onClick={() => setInput(s)}>{s}</button>
          ))}
        </div>
      )}
      <div className="chat-input-row">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKey}
          placeholder="Escribe tu pregunta..."
          rows={1}
          className="chat-input"
        />
        <button className="send-btn" onClick={send} disabled={loading || !input.trim()}>➤</button>
      </div>
    </div>
  );
}

// ─── APP PRINCIPAL ───
export default function App() {
  const [tab, setTab] = useState("calc");
  const [catalogo, setCatalogo] = useState(CATALOGO_DEFAULT);
  const [tasaMensual, setTasaMensual] = useState(3);
  const [showLogin, setShowLogin] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);
  const [adminTaps, setAdminTaps] = useState(0);

  // Tap secreto en el logo (5 veces) para abrir login
  const handleLogoTap = () => {
    setAdminTaps((t) => {
      const next = t + 1;
      if (next >= 5) { setShowLogin(true); return 0; }
      return next;
    });
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;600&display=swap');
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'DM Sans', sans-serif; background: #0d0d0d; color: #f0ede8; min-height: 100vh; }
        .app { max-width: 480px; margin: 0 auto; min-height: 100vh; display: flex; flex-direction: column; background: #111; }

        /* HEADER */
        .app-header { background: #0d0d0d; padding: 20px 20px 0; border-bottom: 1px solid #222; }
        .brand { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; }
        .brand-logo {
          width: 40px; height: 40px; background: #e82d2d; border-radius: 8px;
          display: flex; align-items: center; justify-content: center;
          font-family: 'Bebas Neue', cursive; font-size: 22px; color: #fff;
          cursor: pointer; user-select: none;
        }
        .brand-name { font-family: 'Bebas Neue', cursive; font-size: 20px; letter-spacing: 2px; color: #fff; line-height: 1.1; }
        .brand-sub { font-size: 11px; color: #888; letter-spacing: 1px; text-transform: uppercase; }
        .tabs { display: flex; gap: 4px; }
        .tab-btn {
          flex: 1; padding: 10px 0; border: none; background: transparent; color: #666;
          font-family: 'DM Sans', sans-serif; font-size: 13px; font-weight: 600;
          cursor: pointer; border-bottom: 2px solid transparent; transition: all 0.2s;
          letter-spacing: 0.5px; text-transform: uppercase;
        }
        .tab-btn.active { color: #e82d2d; border-bottom-color: #e82d2d; }
        .content { flex: 1; overflow-y: auto; padding: 20px; }

        /* CAMPOS */
        .field-group { display: flex; flex-direction: column; gap: 8px; }
        .field-group label { font-size: 11px; font-weight: 600; color: #e82d2d; text-transform: uppercase; letter-spacing: 1px; }
        .input-field {
          width: 100%; padding: 10px 14px; background: #1a1a1a; border: 1px solid #333;
          border-radius: 8px; color: #f0ede8; font-family: 'DM Sans', sans-serif;
          font-size: 14px; outline: none; transition: border-color 0.2s;
        }
        .input-field:focus { border-color: #e82d2d; }
        .input-field.error { border-color: #e82d2d; animation: shake 0.3s; }
        @keyframes shake { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-6px)} 75%{transform:translateX(6px)} }

        /* CALCULADORA */
        .calc-wrapper { display: flex; flex-direction: column; gap: 20px; }
        .calc-header { text-align: center; }
        .calc-icon { font-size: 32px; display: block; margin-bottom: 8px; }
        .calc-header h2 { font-family: 'Bebas Neue', cursive; font-size: 26px; letter-spacing: 2px; color: #fff; }
        .calc-header p { font-size: 13px; color: #888; margin-top: 4px; }
        .calc-grid { display: flex; flex-direction: column; gap: 18px; }

        /* MOTOS CARDS */
        .moto-cards { display: flex; flex-direction: column; gap: 8px; }
        .moto-card {
          display: flex; align-items: center; gap: 12px;
          padding: 12px 14px; border-radius: 10px; border: 1px solid #2a2a2a;
          background: #1a1a1a; cursor: pointer; transition: all 0.2s;
        }
        .moto-card.active { border-color: #e82d2d; background: #1f1010; }
        .moto-emoji { font-size: 22px; flex-shrink: 0; }
        .moto-nombre { flex: 1; font-weight: 600; font-size: 14px; color: #f0ede8; }
        .moto-precio { font-size: 13px; color: #e8a02d; font-weight: 600; }

        /* PILLS */
        .price-pills { display: flex; flex-wrap: wrap; gap: 6px; }
        .pill {
          padding: 6px 12px; border-radius: 20px; border: 1px solid #333;
          background: #1a1a1a; color: #ccc; font-size: 12px; cursor: pointer;
          transition: all 0.15s; font-family: 'DM Sans', sans-serif;
        }
        .pill.active, .pill:hover { background: #e82d2d; border-color: #e82d2d; color: #fff; }

        .plazo-pills { display: flex; gap: 6px; flex-wrap: wrap; }
        .plazo-pill {
          flex: 1; min-width: 50px; display: flex; flex-direction: column; align-items: center;
          padding: 10px 6px; border-radius: 10px; border: 1px solid #333;
          background: #1a1a1a; cursor: pointer; transition: all 0.2s; font-family: 'DM Sans', sans-serif;
        }
        .plazo-pill.active { background: #e82d2d; border-color: #e82d2d; }
        .plazo-num { font-size: 20px; font-weight: 700; color: #fff; }
        .plazo-label { font-size: 9px; color: #aaa; }
        .plazo-pill.active .plazo-label { color: rgba(255,255,255,0.7); }

        .alerta { background: #2a1010; border: 1px solid #e82d2d; border-radius: 8px; padding: 10px 14px; font-size: 13px; color: #ff9999; }

        .resultado.vacio { text-align: center; color: #555; font-size: 14px; padding: 30px; background: #1a1a1a; border: 1px solid #2a2a2a; border-radius: 12px; }

        .cuota-grande {
          background: #e82d2d; border-radius: 12px; padding: 20px; text-align: center;
        }
        .cuota-grande > span { font-size: 11px; color: rgba(255,255,255,0.75); text-transform: uppercase; letter-spacing: 1px; }
        .cuota-valor { font-family: 'Bebas Neue', cursive; font-size: 40px; color: #fff; letter-spacing: 1px; line-height: 1.2; }
        .cuota-sub { font-size: 11px; color: rgba(255,255,255,0.7); display: block; margin-top: 4px; }

        /* CHATBOT */
        .chat-wrapper { display: flex; flex-direction: column; height: calc(100vh - 140px); }
        .chat-header { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; padding-bottom: 16px; border-bottom: 1px solid #222; }
        .chat-avatar { width: 44px; height: 44px; border-radius: 50%; background: #e82d2d; display: flex; align-items: center; justify-content: center; font-family: 'Bebas Neue', cursive; font-size: 22px; color: #fff; flex-shrink: 0; }
        .chat-header h2 { font-size: 16px; font-weight: 600; color: #fff; }
        .online-dot { font-size: 11px; color: #4caf50; }
        .chat-messages { flex: 1; overflow-y: auto; display: flex; flex-direction: column; gap: 12px; padding-right: 4px; scrollbar-width: thin; scrollbar-color: #333 transparent; }
        .msg { display: flex; gap: 8px; align-items: flex-end; }
        .msg.user { flex-direction: row-reverse; }
        .msg-avatar { width: 30px; height: 30px; border-radius: 50%; background: #e82d2d; display: flex; align-items: center; justify-content: center; font-family: 'Bebas Neue', cursive; font-size: 16px; color: #fff; flex-shrink: 0; }
        .msg-bubble { max-width: 78%; padding: 10px 14px; border-radius: 16px; font-size: 13.5px; line-height: 1.5; }
        .msg.assistant .msg-bubble { background: #1e1e1e; border: 1px solid #2a2a2a; color: #f0ede8; border-bottom-left-radius: 4px; }
        .msg.user .msg-bubble { background: #e82d2d; color: #fff; border-bottom-right-radius: 4px; }
        .typing { display: flex; align-items: center; gap: 4px; padding: 14px 16px !important; }
        .typing span { width: 6px; height: 6px; background: #888; border-radius: 50%; animation: bounce 1.2s infinite; }
        .typing span:nth-child(2) { animation-delay: 0.2s; }
        .typing span:nth-child(3) { animation-delay: 0.4s; }
        @keyframes bounce { 0%,80%,100%{transform:translateY(0)} 40%{transform:translateY(-6px)} }
        .sugerencias { display: flex; flex-wrap: wrap; gap: 6px; padding: 10px 0; }
        .sug-pill { padding: 6px 12px; border-radius: 20px; border: 1px solid #333; background: #1a1a1a; color: #ccc; font-size: 12px; cursor: pointer; font-family: 'DM Sans', sans-serif; transition: all 0.15s; }
        .sug-pill:hover { border-color: #e82d2d; color: #e8a02d; }
        .chat-input-row { display: flex; gap: 8px; align-items: flex-end; margin-top: 12px; padding-top: 12px; border-top: 1px solid #222; }
        .chat-input { flex: 1; resize: none; background: #1a1a1a; border: 1px solid #333; border-radius: 10px; padding: 10px 14px; color: #f0ede8; font-family: 'DM Sans', sans-serif; font-size: 14px; outline: none; max-height: 100px; transition: border-color 0.2s; }
        .chat-input:focus { border-color: #e82d2d; }
        .send-btn { width: 42px; height: 42px; border-radius: 10px; background: #e82d2d; border: none; color: #fff; font-size: 16px; cursor: pointer; flex-shrink: 0; transition: background 0.2s; }
        .send-btn:disabled { background: #444; cursor: not-allowed; }
        .send-btn:hover:not(:disabled) { background: #c02020; }

        /* ADMIN */
        .admin-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.85); z-index: 100; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .admin-panel { background: #161616; border: 1px solid #2a2a2a; border-radius: 16px; width: 100%; max-width: 440px; max-height: 90vh; overflow-y: auto; padding: 24px; display: flex; flex-direction: column; gap: 20px; }
        .login-box { background: #161616; border: 1px solid #2a2a2a; border-radius: 16px; padding: 32px 24px; width: 100%; max-width: 320px; display: flex; flex-direction: column; align-items: center; gap: 14px; position: relative; }
        .lock-icon { font-size: 40px; }
        .login-box h3 { font-family: 'Bebas Neue', cursive; font-size: 22px; letter-spacing: 2px; color: #fff; }
        .error-msg { color: #e82d2d; font-size: 12px; }
        .admin-header { display: flex; justify-content: space-between; align-items: center; }
        .admin-header h2 { font-family: 'Bebas Neue', cursive; font-size: 22px; letter-spacing: 1px; color: #fff; }
        .close-btn { background: #2a2a2a; border: none; color: #aaa; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; font-size: 14px; position: absolute; top: 16px; right: 16px; }
        .admin-section { display: flex; flex-direction: column; gap: 12px; }
        .admin-section h3 { font-size: 13px; font-weight: 700; color: #e82d2d; text-transform: uppercase; letter-spacing: 1px; }
        .admin-section h4 { font-size: 12px; color: #888; margin-top: 8px; }
        .tasa-row { display: flex; align-items: center; gap: 8px; }
        .tasa-row .input-field { width: 90px; }
        .tasa-pct { font-size: 14px; color: #aaa; }
        .admin-note { font-size: 11px; color: #666; }
        .btn-guardar { background: #e82d2d; border: none; color: #fff; padding: 9px 16px; border-radius: 8px; cursor: pointer; font-family: 'DM Sans', sans-serif; font-size: 13px; font-weight: 600; transition: background 0.2s; }
        .btn-guardar:hover { background: #c02020; }
        .btn-guardar.full { width: 100%; padding: 12px; }
        .catalogo-list { display: flex; flex-direction: column; gap: 8px; }
        .catalogo-item { display: flex; align-items: center; justify-content: space-between; background: #1a1a1a; border: 1px solid #2a2a2a; border-radius: 8px; padding: 10px 12px; }
        .cat-info { display: flex; flex-direction: column; gap: 2px; }
        .cat-info strong { font-size: 14px; color: #f0ede8; }
        .cat-info span { font-size: 12px; color: #e8a02d; }
        .btn-del { background: none; border: none; cursor: pointer; font-size: 16px; color: #666; transition: color 0.2s; }
        .btn-del:hover { color: #e82d2d; }
        .add-moto { display: flex; flex-direction: column; gap: 8px; }
        .add-row { display: flex; gap: 8px; }
        .add-row .input-field { flex: 1; }
        .btn-agregar { background: #1a1a1a; border: 1px solid #e82d2d; color: #e82d2d; padding: 10px 14px; border-radius: 8px; cursor: pointer; font-size: 13px; font-weight: 600; white-space: nowrap; font-family: 'DM Sans', sans-serif; transition: all 0.2s; }
        .btn-agregar:hover { background: #e82d2d; color: #fff; }

        /* FOOTER */
        .app-footer { padding: 10px 20px; text-align: center; font-size: 11px; color: #444; border-top: 1px solid #1a1a1a; }
      `}</style>

      {showLogin && !showAdmin && (
        <LoginAdmin
          onLogin={() => { setShowLogin(false); setShowAdmin(true); }}
          onClose={() => setShowLogin(false)}
        />
      )}
      {showAdmin && (
        <PanelAdmin
          catalogo={catalogo}
          setCatalogo={setCatalogo}
          tasaMensual={tasaMensual}
          setTasaMensual={setTasaMensual}
          onClose={() => setShowAdmin(false)}
        />
      )}

      <div className="app">
        <div className="app-header">
          <div className="brand">
            <div className="brand-logo" onClick={handleLogoTap}>C</div>
            <div>
              <div className="brand-name">Caribemar</div>
              <div className="brand-sub">La Romana · RD · 809-349-4268</div>
            </div>
          </div>
          <div className="tabs">
            <button className={`tab-btn ${tab === "calc" ? "active" : ""}`} onClick={() => setTab("calc")}>
              🏍️ Cotizar
            </button>
            <button className={`tab-btn ${tab === "chat" ? "active" : ""}`} onClick={() => setTab("chat")}>
              💬 Asistente
            </button>
          </div>
        </div>

        <div className="content">
          {tab === "calc"
            ? <Calculadora catalogo={catalogo} tasaMensual={tasaMensual} />
            : <Chatbot catalogo={catalogo} tasaMensual={tasaMensual} />
          }
        </div>

        <div className="app-footer">
          © Inversiones Caribemar SRL · RNC 131734413
        </div>
      </div>
    </>
  );
}
